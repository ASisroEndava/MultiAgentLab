# Multi-Agent Systems: Theory and Implementation

## A Practical Guide for Technical Audiences

**Project:** MultiAgentLab  
**Date:** 2026-05-12  
**Audience:** Software engineers and architects familiar with distributed systems but new to multi-agent concepts

---

## 1. What Is a Multi-Agent System?

A **multi-agent system (MAS)** is a computational architecture where multiple autonomous entities — called **agents** — collaborate, negotiate, or compete to solve a problem that is beyond the capability (or efficiency) of any single agent working alone.

Each agent has three defining properties:

| Property | Description |
|---|---|
| **Autonomy** | The agent decides *how* to perform its task without step-by-step instructions from a central controller. |
| **Specialization** | The agent possesses domain-specific knowledge that makes its judgment authoritative within its scope. |
| **Structured output** | The agent communicates results in a format other agents (or a coordinator) can consume programmatically. |

### Why not just one big model?

A single LLM prompted with "review this user story for quality, security, UX, testability, and compliance" produces a monolithic response where concerns bleed together, important nuances get lost, and it is impossible to trace *which perspective* raised *which issue*. A multi-agent approach decomposes the problem so that:

- Each perspective gets its own dedicated reasoning context.
- Results are individually scored, traceable, and auditable.
- The system can selectively invoke only the agents that are relevant to a given input.

---

## 2. Core Concepts

### 2.1 Agent

An agent is a self-contained unit of reasoning. In an LLM-powered multi-agent system, each agent is typically defined by:

1. **A system prompt** — the agent's "expertise" and instructions. This is the fixed identity that does not change between executions.
2. **An input context** — the specific data the agent must analyze (e.g., a user story).
3. **A structured output contract** — the expected JSON schema the agent must return.

In MultiAgentLab, agents are modeled as implementations of the `IReviewAgent` interface:

```
IReviewAgent
├── ClarityAgent      → Detects ambiguities and missing definitions
├── QaAgent           → Evaluates testability and acceptance criteria
├── TechnicalAgent    → Identifies technical risks and integration concerns
├── UxAgent           → Assesses user experience and interaction design
└── ComplianceAgent   → Checks for security, privacy, and regulatory issues
```

Each agent inherits from `BaseReviewAgent`, which encapsulates the common lifecycle: build prompt → call LLM → parse response.

### 2.2 Supervisor (Orchestrator)

The **supervisor** is the central coordinator. It does not perform domain analysis itself; instead, it:

1. **Selects** which agents to invoke based on input characteristics.
2. **Dispatches** work to the selected agents (potentially in parallel).
3. **Collects** and aggregates results.
4. **Detects conflicts** between agent recommendations.
5. **Resolves conflicts** using predefined priority rules.
6. **Synthesizes** a final verdict (status, summary, consolidated findings).

This pattern is known as a **supervisor architecture** or **orchestrator pattern**, as opposed to:

- **Peer-to-peer** — agents communicate directly with each other.
- **Blackboard** — agents read/write to a shared knowledge base.
- **Hierarchical** — multiple supervisors at different levels.

The supervisor pattern was chosen here because it provides maximum observability and deterministic control flow — critical for a system whose output must be auditable and explainable.

### 2.3 Agent Selection (Dynamic Routing)

Not every user story needs every agent. A story that says *"Change the Save button to Confirm"* does not need a compliance review. Invoking all agents wastes compute and adds noise.

The `AgentSelectionRules` component analyzes the input text for **domain-specific keywords** and determines which agents to invoke:

| Signal detected | Agents invoked |
|---|---|
| UI/UX keywords (button, form, screen...) | `ux` |
| Technical keywords (retry, async, webhook...) | `technical` |
| Compliance keywords (PII, audit, GDPR...) | `compliance` |
| QA keywords (validation, criteria, error...) | `qa` |
| Trivial change (rename, change label...) | Only `clarity` + `ux` |
| Complex story (multiple domains) | All relevant agents |

`clarity` is always invoked because every story benefits from a functional clarity review.

Agents that are not invoked are recorded as **skipped** with a reason, ensuring full transparency in the execution trace.

### 2.4 Parallel Execution

Once agents are selected, the supervisor dispatches them concurrently using `Task.WhenAll`. This is possible because agents are **independent** — they analyze the same input but do not depend on each other's output. This parallelism significantly reduces total execution time: instead of summing each agent's LLM latency, the total latency is approximately equal to the *slowest* agent.

```
Time ──────────────────────────────────────────►

Sequential:  [clarity: 5s] → [qa: 6s] → [tech: 4s] → [ux: 5s]  = 20s total

Parallel:    [clarity: 5s]
             [qa:      6s]    ← total = 6s (slowest agent)
             [tech:    4s]
             [ux:      5s]
```

### 2.5 Conflict Detection and Resolution

When multiple specialized agents analyze the same story, their recommendations may **conflict**. For example:

- **UX** recommends simplifying a flow by removing steps.
- **Compliance** requires those steps for audit trail integrity.

The `ConflictResolver` component detects these tensions by cross-referencing agent outputs using keyword heuristics. When a conflict is found, it applies **resolution rules** with a priority hierarchy:

```
Compliance > Technical Feasibility > Testability (QA) > Clarity > UX
```

This means if UX wants to simplify and Compliance says "no, we need identity verification", Compliance wins. The conflict and its resolution are both recorded in the execution trace.

Current conflict detection rules:

| Conflict | Resolution |
|---|---|
| UX simplification vs. Technical restrictions | Prioritize technical feasibility; apply visible restrictions in UI |
| UX simplification vs. Compliance requirements | Compliance takes priority; maintain security validations |
| QA detects severe missing acceptance criteria | Final status cannot be green while criteria are absent |

### 2.6 Result Aggregation and Final Verdict

After all agents complete and conflicts are resolved, the supervisor aggregates:

- **All issues** from all agents (deduplicated).
- **All recommendations** from all agents (deduplicated).
- **A status** (green / yellow / red) based on issue count, error count, average score, and conflict severity.
- **A human-readable summary** describing the overall story quality.

The scoring logic:

| Condition | Status |
|---|---|
| Errors, >6 issues, or ≥2 conflicts | 🔴 Red |
| >2 issues, ≥1 conflict, avg score <0.6, or parse errors | 🟡 Yellow |
| Everything else | 🟢 Green |

---

## 3. How an Execution Flows End to End

Below is the complete lifecycle of a single review request:

```
┌──────────────────────────────────────────────────────────────────┐
│  1. REQUEST RECEIVED                                             │
│     Input: storyId, title, storyText, provider, logging options  │
└──────────────────────┬───────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  2. SUPERVISOR STARTED                                           │
│     Generates executionId, begins logging                        │
└──────────────────────┬───────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  3. AGENT SELECTION                                              │
│     AgentSelectionRules analyzes keywords in story text          │
│     → Determines: [clarity, qa, ux] invoked                     │
│     → Determines: [technical, compliance] skipped (with reason)  │
└──────────────────────┬───────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  4. PARALLEL AGENT EXECUTION                                     │
│                                                                  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │  Clarity     │  │  QA          │  │  UX          │             │
│  │  Agent       │  │  Agent       │  │  Agent       │             │
│  │             │  │             │  │             │              │
│  │ Build prompt │  │ Build prompt │  │ Build prompt │             │
│  │ Call LLM     │  │ Call LLM     │  │ Call LLM     │             │
│  │ Parse JSON   │  │ Parse JSON   │  │ Parse JSON   │             │
│  │ Return result│  │ Return result│  │ Return result│             │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘              │
│         └────────────────┼────────────────┘                      │
│                          ▼                                       │
│                   Task.WhenAll()                                 │
└──────────────────────┬───────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  5. CONFLICT DETECTION & RESOLUTION                              │
│     ConflictResolver cross-references agent outputs              │
│     → Detects: "UX simplification vs QA testability gap"         │
│     → Resolves: "Maintain acceptance criteria"                   │
└──────────────────────┬───────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  6. RESULT AGGREGATION                                           │
│     - Merge all issues (deduplicated)                            │
│     - Merge all recommendations (deduplicated)                   │
│     - Calculate status: green / yellow / red                     │
│     - Build human-readable summary                               │
└──────────────────────┬───────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  7. FINAL RESULT                                                 │
│     ReviewResult with executionId, status, summary,              │
│     per-agent results, conflicts, resolutions                    │
│     → Logged to JSONL for full auditability                      │
└──────────────────────────────────────────────────────────────────┘
```

---

## 4. The Role of LLMs in This Architecture

In this multi-agent system, each agent uses a Large Language Model (LLM) as its "reasoning engine". The agent does not contain hard-coded analysis rules — instead, it:

1. Constructs a **prompt** that combines its system prompt (persona/expertise) with the user story.
2. Sends the prompt to an LLM via a **model client** (Ollama for local models, Bedrock for AWS cloud models).
3. Receives a natural-language response and **parses** it into structured JSON.

### Model Provider Abstraction

The system supports multiple LLM providers through a clean abstraction:

```
IModelClient (interface)
├── OllamaClient    → Local models via Ollama API (e.g., qwen2.5, llama3, phi3)
└── BedrockClient   → AWS Bedrock models (Claude, Nova, Llama, Mistral)

IModelRouter (interface)
└── Resolves which IModelClient to use based on ProviderSelection
```

This means the same agent logic works identically whether the LLM is running locally on your machine or in the AWS cloud. The provider is selected at request time, enabling **cross-model comparison** — running the same story through different models to compare quality and consistency.

### Why Structured Output Matters

The prompt instructs each agent to respond in a specific JSON format:

```json
{
  "issues": ["string", ...],
  "recommendations": ["string", ...],
  "questions": ["string", ...],
  "rawSummary": "string"
}
```

This is critical because the supervisor must **programmatically** aggregate results from multiple agents. Without structured output, the system would need another LLM call just to extract findings from free-text responses — adding latency, cost, and fragility.

However, LLMs are imperfect JSON generators. They may produce unescaped quotes, newlines inside strings, or missing brackets. The `BaseReviewAgent.ParseResponse` includes a multi-stage repair pipeline:

1. **Direct parse** — try the raw JSON.
2. **Repair** — fix newlines, unescaped quotes, missing commas.
3. **Complete** — close unclosed brackets/arrays for truncated responses.
4. **Repair + Complete** — apply both fixes.

---

## 5. Observability and Traceability

Every step of the execution is logged as a structured event in JSONL format:

| Event Type | When | Data |
|---|---|---|
| `request_received` | Start | Full request payload |
| `supervisor_started` | Before selection | ExecutionId |
| `selected_agents` | After selection | Invoked + skipped agents with reasons |
| `agent_started` | Before each agent | Agent name |
| `agent_prompt_sent` | Before LLM call | Full prompt (if `includePrompts` enabled) |
| `agent_response_received` | After LLM call | Raw LLM response (if `includeResponses` enabled) |
| `agent_completed` | After parsing | Parsed result with score, issues, recommendations |
| `agent_failed` | On error | Error message |
| `conflicts_detected` | If conflicts found | List of conflicts |
| `supervisor_resolution` | If conflicts resolved | List of resolutions |
| `final_result_generated` | End | Complete ReviewResult |
| `request_completed` | End | Total elapsed milliseconds |

This event stream enables:

- **Post-mortem analysis** — understanding exactly why an agent failed or produced unexpected results.
- **Debugging parse errors** — seeing the raw LLM response when JSON parsing fails.
- **Performance profiling** — identifying slow agents or slow model responses.
- **Execution replay** — the full history tab in the UI reconstructs the timeline from these events.

---

## 6. Multi-Agent vs. Other Approaches

| Approach | Description | Trade-offs |
|---|---|---|
| **Single prompt** | One LLM call with all instructions | Simple but unstructured; no traceability; mixed concerns |
| **Chain of thought** | One LLM, sequential reasoning steps | Better quality but single perspective; no parallel execution |
| **RAG (Retrieval-Augmented)** | Enrich prompt with retrieved context | Good for knowledge grounding; doesn't decompose the problem |
| **Multi-agent (this project)** | Multiple specialized LLM calls, coordinated by supervisor | Best decomposition; full traceability; parallel execution; conflict resolution |

### When to use multi-agent

Multi-agent is most beneficial when:

- The problem has **multiple orthogonal dimensions** (quality, security, UX, compliance).
- You need **traceable, auditable** results (who said what and why).
- Different dimensions may **conflict** and require explicit resolution.
- You want to **compare** different models or configurations on the same task.
- The input domain is varied enough that **not all agents are always needed**.

---

## 7. Architecture Diagram

```
                    ┌─────────────────────────────┐
                    │        HTTP Request          │
                    │  POST /review-story          │
                    └──────────────┬──────────────┘
                                   │
                                   ▼
                    ┌─────────────────────────────┐
                    │      ReviewSupervisor        │
                    │  (Orchestrator)              │
                    │                             │
                    │  ┌───────────────────────┐  │
                    │  │ AgentSelectionRules    │  │
                    │  │ (keyword analysis)     │  │
                    │  └───────────┬───────────┘  │
                    │              │               │
                    │              ▼               │
                    │  ┌───────────────────────┐  │
                    │  │ Parallel Dispatch      │  │
                    │  │ Task.WhenAll(agents)   │  │
                    │  └───────────┬───────────┘  │
                    │              │               │
                    │              ▼               │
                    │  ┌───────────────────────┐  │
                    │  │ ConflictResolver       │  │
                    │  │ (cross-agent analysis) │  │
                    │  └───────────┬───────────┘  │
                    │              │               │
                    │              ▼               │
                    │  Result Aggregation          │
                    │  Status + Summary            │
                    └──────────────┬──────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              ▼                    ▼                    ▼
     ┌────────────┐      ┌────────────┐      ┌────────────┐
     │  Clarity    │      │  QA         │      │  Technical  │  ...
     │  Agent      │      │  Agent      │      │  Agent      │
     └──────┬─────┘      └──────┬─────┘      └──────┬─────┘
            │                    │                    │
            ▼                    ▼                    ▼
     ┌─────────────────────────────────────────────────────┐
     │              IModelRouter                           │
     │  ┌──────────────┐       ┌──────────────┐            │
     │  │ OllamaClient │       │ BedrockClient│            │
     │  │ (local LLMs) │       │ (AWS cloud)  │            │
     │  └──────────────┘       └──────────────┘            │
     └─────────────────────────────────────────────────────┘
```

---

## 8. Key Design Decisions

| Decision | Rationale |
|---|---|
| **Supervisor pattern** over peer-to-peer | Deterministic flow, full observability, simpler debugging |
| **Keyword-based selection** over LLM-based routing | Zero additional LLM calls for routing; fast and predictable |
| **Parallel agent execution** | Latency = slowest agent, not sum of all agents |
| **Structured JSON output** | Enables programmatic aggregation without secondary LLM calls |
| **Multi-stage JSON repair** | LLMs are unreliable JSON generators; repair is cheaper than re-prompting |
| **Provider abstraction** (IModelClient) | Same agent code works with any LLM provider |
| **JSONL event logging** | Append-only, easy to parse, one file per execution |
| **Conflict resolution with fixed priorities** | Deterministic and explainable; no LLM needed for resolution |

---

## 9. Glossary

| Term | Definition |
|---|---|
| **Agent** | An autonomous unit with a specialized role, a system prompt, and a structured output contract |
| **Supervisor / Orchestrator** | The component that selects, dispatches, and coordinates agents |
| **Agent Selection** | The process of deciding which agents to invoke based on input characteristics |
| **Conflict Resolution** | Detecting contradictions between agent recommendations and applying priority rules |
| **System Prompt** | The fixed instruction set that defines an agent's expertise and behavior |
| **Structured Output** | A predefined JSON schema that agents must follow for programmatic processing |
| **Model Router** | The abstraction that directs LLM calls to the appropriate provider (Ollama, Bedrock) |
| **Execution Trace** | The JSONL event log that records every step of a review execution |
| **Parse Error** | When an LLM response cannot be converted to the expected JSON structure |
| **Status (green/yellow/red)** | The traffic-light verdict produced by the supervisor based on aggregated findings |

---

## 10. References and Further Reading

- **Stuart Russell & Peter Norvig** — *Artificial Intelligence: A Modern Approach* (Chapter on Multi-Agent Systems)
- **Michael Wooldridge** — *An Introduction to MultiAgent Systems* (foundational textbook)
- **Andrew Ng** — *Agentic Design Patterns* (2024 series on LLM agent architectures)
- **LangChain / LangGraph** — Open-source frameworks implementing multi-agent patterns
- **AutoGen (Microsoft)** — Multi-agent conversation framework
- **CrewAI** — Role-based multi-agent orchestration library
